package com.jaiafy.app
import android.content.Context
import org.json.JSONArray
import java.io.File

/** ذاكرة محلية على الجهاز فقط (ملف داخل مساحة التطبيق الخاصة). */
class Memory(ctx: Context) {
    private val file = File(ctx.filesDir, "memory.json")
    private val facts = JSONArray(if (file.exists()) file.readText() else "[]")
    fun add(fact: String) { facts.put(fact); file.writeText(facts.toString()) }
    fun all(): String = (0 until facts.length()).joinToString("\n") { "- " + facts.getString(it) }
}
