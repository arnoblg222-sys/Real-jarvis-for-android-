package com.jaiafy.app
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.abs

/** نواة جايفاي كنافذة عائمة فوق التطبيقات الأخرى (تحتاج إذن "الظهور فوق التطبيقات"). */
object OverlayCore {
    private var view: View? = null

    fun show(c: Context) {
        if (view != null || !Settings.canDrawOverlays(c)) return
        val ctx = c.applicationContext
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val size = (150 * ctx.resources.displayMetrics.density).toInt()
        val hud = JarvisHud(ctx).apply { overlayMode = true }
        val lp = WindowManager.LayoutParams(size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 300 }
        hud.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                        if (abs(dx) > 10 || abs(dy) > 10) moved = true
                        lp.x = ox + dx; lp.y = oy + dy; wm.updateViewLayout(v, lp)
                    }
                    MotionEvent.ACTION_UP -> if (!moved) ctx.startActivity(
                        Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
                return true
            }
        })
        try { wm.addView(hud, lp); view = hud } catch (_: Exception) {}
    }

    fun hide(c: Context) {
        val v = view ?: return
        try { (c.applicationContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v) } catch (_: Exception) {}
        view = null
    }
}
