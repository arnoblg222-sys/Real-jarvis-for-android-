package com.jaiafy.app
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.hardware.usb.UsbManager
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import org.json.JSONObject

/** ينفّذ الأوامر القادمة من العقل. يرجع نصاً إضافياً لينطقه إن لزم. */
class Actions(private val c: Context, private val mem: Memory) {
    private val sc get() = ScreenControlService.inst

    fun run(a: JSONObject): String? {
        val arg = a.optString("arg")
        when (a.optString("type")) {
            "open_app" -> {
                val pm = c.packageManager
                val app = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                    .firstOrNull { it.loadLabel(pm).toString().contains(arg, true) }
                app?.let { c.startActivity(pm.getLaunchIntentForPackage(it.activityInfo.packageName)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                    ?: return "لم أجد التطبيق $arg"
            }
            "click_text" -> if (sc?.clickText(arg) != true) return "لم أجد $arg على الشاشة"
            "type_text" -> sc?.typeText(arg)
            "back" -> sc?.back(); "home" -> sc?.home(); "recents" -> sc?.recents()
            "scroll_down" -> sc?.swipe(true); "scroll_up" -> sc?.swipe(false)
            "search_web" -> openBrowser("https://www.google.com/search?q=" + Uri.encode(arg))
            "open_url" -> openBrowser(arg)
            "call" -> c.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$arg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "flashlight_on", "flashlight_off" -> {
                val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                cm.setTorchMode(cm.cameraIdList[0], a.optString("type") == "flashlight_on")
            }
            "volume_up", "volume_down" -> (c.getSystemService(Context.AUDIO_SERVICE) as AudioManager).adjustStreamVolume(
                AudioManager.STREAM_MUSIC, if (a.optString("type") == "volume_up") AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            "bt_list" -> return try {
                val bt = (c.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
                "الأجهزة المقترنة: " + bt.bondedDevices.joinToString("، ") { it.name }
            } catch (e: SecurityException) { "أحتاج إذن البلوتوث" }
            "usb_list" -> return "أجهزة USB: " + (c.getSystemService(Context.USB_SERVICE) as UsbManager).deviceList.values.joinToString("، ") { it.productName ?: it.deviceName }.ifBlank { "لا يوجد" }
            "remember" -> mem.add(arg)
            "show_cam" -> Handler(Looper.getMainLooper()).post { CameraFeed.show(c, Brain.get(c, "cam_url")) }
            "hide_cam" -> Handler(Looper.getMainLooper()).post { CameraFeed.hide(c) }
            "light_status" -> return SmartHome.describe(c)
            "light_on", "light_off" -> return if (SmartHome.set(c, a.optString("type") == "light_on")) null else "تعذر التحكم بالنور"
        }
        return null
    }

    /** يفتح Chromium إن كان مثبتاً، وإلا Chrome، وإلا المتصفح الافتراضي. */
    private fun openBrowser(url: String) {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        for (pkg in listOf("org.chromium.chrome", "com.android.chrome")) {
            if (c.packageManager.getLaunchIntentForPackage(pkg) != null) { c.startActivity(i.setPackage(pkg)); return }
        }
        c.startActivity(i)
    }
}
