package com.jaiafy.app
import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** التحكم بالنور وقراءة حالته عبر Home Assistant (واجهة REST). */
object SmartHome {
    private fun call(c: Context, path: String, post: String?): String? = try {
        val base = Brain.get(c, "ha_url").trimEnd('/')
        if (base.isBlank()) null
        else {
            val con = URL(base + path).openConnection() as HttpURLConnection
            con.connectTimeout = 8000; con.readTimeout = 8000
            con.setRequestProperty("Authorization", "Bearer " + Brain.get(c, "ha_token"))
            if (post != null) {
                con.requestMethod = "POST"; con.doOutput = true
                con.setRequestProperty("Content-Type", "application/json")
                con.outputStream.use { it.write(post.toByteArray()) }
            }
            if (con.responseCode in 200..299) con.inputStream.bufferedReader().readText() else null
        }
    } catch (e: Exception) { null }

    fun state(c: Context): String? {
        val ent = Brain.get(c, "ha_entity")
        if (ent.isBlank()) return null
        val r = call(c, "/api/states/$ent", null) ?: return null
        return try { JSONObject(r).optString("state") } catch (e: Exception) { null }
    }

    fun set(c: Context, on: Boolean): Boolean {
        val ent = Brain.get(c, "ha_entity")
        if (ent.isBlank()) return false
        val svc = if (on) "turn_on" else "turn_off"
        return call(c, "/api/services/" + ent.substringBefore('.') + "/" + svc, JSONObject().put("entity_id", ent).toString()) != null
    }

    fun describe(c: Context): String {
        val s = state(c)
        return when (s) {
            "on" -> "النور مفتوح"
            "off" -> "النور مغلق"
            null -> "تعذر قراءة حالة النور"
            else -> "حالة النور: $s"
        }
    }
}
