package com.jaiafy.app
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

/** وجه هولوغرافي سلكي يدور ببطء (أزرق، أو أحمر في وضع Serious). */
class FaceView(c: Context) : View(c) {
    private val t0 = System.nanoTime()
    private val ln = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 2f; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val fl = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val tx = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    }
    private fun col(a: Int, rgb: Int) = (a shl 24) or (rgb and 0xFFFFFF)

    override fun onDraw(cv: Canvas) {
        val t = (System.nanoTime() - t0) / 1e9f
        val rgb = if (Mode.serious) 0xFF4D4D else 0x5FE3FF
        val w = width.toFloat(); val h = height.toFloat()
        fl.color = col(0xFF, if (Mode.serious) 0x0A0203 else 0x02070D)
        cv.drawRect(0f, 0f, w, h, fl)
        val cx = w / 2f; val cy = h * 0.46f; val r = minOf(w, h) * 0.30f
        val ang = t * 0.7f
        val ca = cos(ang); val sa = sin(ang)
        val a = FloatArray(3); val b = FloatArray(3)

        fun pt(lat: Double, lon: Double, out: FloatArray) {
            var x = (0.78 * cos(lat) * sin(lon)).toFloat()
            val y = (-1.05 * sin(lat)).toFloat()
            var z = (0.85 * cos(lat) * cos(lon)).toFloat()
            if (y > 0.35f) { val k = 1f - (y - 0.35f) * 0.45f; x *= k; z *= k }
            out[0] = cx + (x * ca + z * sa) * r
            out[1] = cy + y * r
            out[2] = -x * sa + z * ca
        }
        fun seg(la1: Double, lo1: Double, la2: Double, lo2: Double) {
            pt(la1, lo1, a); pt(la2, lo2, b)
            val depth = (a[2] + b[2]) / 2f
            val alpha = (60 + 150 * ((depth + 0.9f) / 1.8f)).toInt().coerceIn(30, 220)
            ln.color = col(alpha, rgb)
            cv.drawLine(a[0], a[1], b[0], b[1], ln)
        }
        val deg = Math.PI / 180.0
        var lat = -75
        while (lat <= 75) {
            var lon = 0
            while (lon < 360) { seg(lat * deg, lon * deg, lat * deg, (lon + 10) * deg); lon += 10 }
            lat += 15
        }
        var lon = 0
        while (lon < 360) {
            var la = -80
            while (la < 80) { seg(la * deg, lon * deg, (la + 10) * deg, lon * deg); la += 10 }
            lon += 20
        }

        // العينان
        fl.color = col(0xFF, 0xFFFFFF)
        for (sx in listOf(-0.3f, 0.3f)) {
            val x = sx; val y = -0.2f; val z = 0.8f
            val zr = -x * sa + z * ca
            if (zr > 0.1f) cv.drawCircle(cx + (x * ca + z * sa) * r, cy + y * r, r * 0.04f, fl)
        }
        // خط المسح
        val sy = cy - r * 1.1f + ((t * 0.5f) % 1f) * r * 2.2f
        ln.color = col(0xAA, rgb); ln.strokeWidth = 3f
        cv.drawLine(cx - r * 0.85f, sy, cx + r * 0.85f, sy, ln)
        ln.strokeWidth = 2f

        tx.color = col(0xFF, rgb); tx.textSize = r * 0.14f
        cv.drawText("J.A.I.A.F.Y", cx, cy + r * 1.45f, tx)
        postInvalidateOnAnimation()
    }
}
