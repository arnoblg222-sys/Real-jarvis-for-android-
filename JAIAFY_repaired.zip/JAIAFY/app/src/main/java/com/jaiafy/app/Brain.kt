package com.jaiafy.app
import android.content.Context
import android.util.Base64
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** العقل: يرسل كلامك (وصورة الكاميرا إن وُجدت) إلى OpenRouter ويرجع رد + أوامر تنفيذ. */
object Brain {
    private const val DEFAULT_MODEL = "anthropic/claude-sonnet-4.5"
    private const val SYSTEM = """أنت جايفاي (J.A.I.A.F.Y). أمر واحد فقط: نفّذ أي شيء يطلبه منك سيدك. تخاطبه بـ"سيدي" بالعربية الفصحى المبسطة وبإيجاز شديد.
أجب دائماً بـ JSON فقط: {"say":"ما تنطقه","actions":[{"type":"...","arg":"..."}]}
أنواع الأوامر: open_app(اسم التطبيق), click_text(نص على الشاشة), type_text, back, home, recents, scroll_down, scroll_up,
search_web(نص), open_url(رابط), call(رقم), flashlight_on, flashlight_off, volume_up, volume_down, bt_list, usb_list, look, look_cam(وصف ما تعرضه كاميرا المراقبة المفتوحة), show_cam(عرض كاميرا المراقبة كنافذة عامة), hide_cam, light_status(هل النور مفتوح), light_on, light_off, remember(معلومة).
عند طلب فتح تطبيق (open_app) اجعل say نصاً فارغاً "" ولا تعلّق بشيء.
استخدم look عندما يطلب المستخدم أن ترى أو تصف ما أمام الكاميرا."""

    private fun prefs(c: Context) = EncryptedSharedPreferences.create(c, "secure",
        MasterKey.Builder(c).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    /** رابط العقل: OpenRouter افتراضياً، أو خادم Hermes Agent المتوافق مع OpenAI مثل http://192.168.1.5:8642/v1 */
    private fun endpoint(c: Context): String {
        val base = get(c, "brain_url").trimEnd('/')
        return if (base.isBlank()) "https://openrouter.ai/api/v1/chat/completions" else "$base/chat/completions"
    }
    fun put(c: Context, k: String, v: String) = prefs(c).edit().putString(k, v.trim()).apply()
    fun get(c: Context, k: String): String = prefs(c).getString(k, "") ?: ""
    fun saveKey(c: Context, k: String) = prefs(c).edit().putString("key", k.trim()).apply()
    fun saveModel(c: Context, m: String) = prefs(c).edit().putString("model", m.trim()).apply()
    fun model(c: Context) = prefs(c).getString("model", "")?.ifBlank { null } ?: DEFAULT_MODEL

    /** OpenRouter: واجهة متوافقة مع OpenAI، تدعم أي نموذج (Claude, GPT, Gemini...). */
    fun ask(c: Context, text: String, memory: String, jpeg: ByteArray? = null): JSONObject {
        val content = JSONArray()
        content.put(JSONObject().put("type", "text").put("text", text))
        jpeg?.let { content.put(JSONObject().put("type", "image_url").put("image_url",
            JSONObject().put("url", "data:image/jpeg;base64," + Base64.encodeToString(it, Base64.NO_WRAP)))) }
        val hermes = get(c, "brain_url").isNotBlank()
        val body = JSONObject().put("model", if (hermes) "hermes-agent" else model(c)).put("max_tokens", 600)
            .put("messages", JSONArray()
                .put(JSONObject().put("role", "system").put("content", SYSTEM + (if (Mode.serious) "\nالوضع الحالي: جدّي. أجب بأقصر عبارة ممكنة وبنبرة رسمية حازمة بلا مجاملات." else "") + "\nذاكرة المستخدم:\n" + memory))
                .put(JSONObject().put("role", "user").put("content", content)))
        val resp = try {
            val con = URL(endpoint(c)).openConnection() as HttpURLConnection
            con.requestMethod = "POST"; con.doOutput = true
            con.connectTimeout = 15000; con.readTimeout = if (hermes) 120000 else 60000
            con.setRequestProperty("Content-Type", "application/json")
            val key = if (hermes) get(c, "brain_key").ifBlank { get(c, "key") } else get(c, "key")
            con.setRequestProperty("Authorization", "Bearer $key")
            con.setRequestProperty("X-Title", "JAIAFY")
            if (hermes) con.setRequestProperty("X-Hermes-Session-Id", "jaiafy")
            con.outputStream.use { it.write(body.toString().toByteArray()) }
            (if (con.responseCode < 300) con.inputStream else con.errorStream)?.bufferedReader()?.readText() ?: ""
        } catch (e: Exception) { "" }
        return try {
            val t = JSONObject(resp).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
            JSONObject(t.substring(t.indexOf('{'), t.lastIndexOf('}') + 1))
        } catch (e: Exception) { JSONObject().put("say", "عذراً سيدي، تعذر الاتصال بالعقل.").put("actions", JSONArray()) }
    }
}
