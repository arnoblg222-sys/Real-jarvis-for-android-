package com.jaiafy.app
import android.Manifest
import android.app.DownloadManager
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import java.io.File

/** Holo Desk: الكاميرا كخلفية، وفوقها نوافذ زجاجية (تطبيقات، صور، ملفات، متصفح) تُسحب وتُفتح من الشريط السفلي. */
class HoloDeskView(private val act: FragmentActivity) : FrameLayout(act) {
    private val d = resources.displayMetrics.density
    private fun dp(v: Int) = (v * d).toInt()
    private val cy = 0xFF5FE3FF.toInt()
    private val preview = PreviewView(act).apply {
        implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        scaleType = PreviewView.ScaleType.FILL_CENTER
    }
    private var started = false
    private var provider: ProcessCameraProvider? = null
    private var useCase: Preview? = null
    private var analysisCase: ImageAnalysis? = null
    private val status = TextView(act).apply { setTextColor(0xFF8FA6B8.toInt()); textSize = 11f }
    private val tracker = HandTracker(act, { hands, iw, ih -> onHands(hands, iw, ih) }, { s -> status.text = s })
    private val cursors = List(2) { Dot(act).apply { visibility = View.GONE } }
    private val pinching = BooleanArray(2)
    private val grabbed = arrayOfNulls<GlassPanel>(2)
    private val lastX = FloatArray(2)
    private val lastY = FloatArray(2)
    private val panels = HashMap<String, GlassPanel>()
    private var selected: GlassPanel? = null
    private val onSelect: (GlassPanel) -> Unit = { p -> selected?.select(false); p.select(true); selected = p }
    private var cascade = 0

    init {
        setBackgroundColor(0xFF02070D.toInt())
        addView(preview, FrameLayout.LayoutParams(-1, -1))
        addView(View(act).apply { setBackgroundColor(0x55020B14) }, FrameLayout.LayoutParams(-1, -1))
        val dock = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        for ((label, key) in listOf("التطبيقات" to "apps", "الصور" to "photos", "الملفات" to "files", "المتصفح" to "browser")) {
            val b = TextView(act).apply {
                text = label; gravity = Gravity.CENTER; setTextColor(cy); textSize = 11f
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x44104060); setStroke(dp(1), cy) }
                setOnClickListener { toggle(key) }
            }
            dock.addView(b, LinearLayout.LayoutParams(dp(68), dp(68)).apply { setMargins(dp(6), 0, dp(6), 0) })
        }
        addView(dock, FrameLayout.LayoutParams(-2, -2).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; bottomMargin = dp(28) })
        addView(status, FrameLayout.LayoutParams(-2, -2).apply { gravity = Gravity.TOP or Gravity.START; topMargin = dp(64); leftMargin = dp(12) })
        cursors.forEach { addView(it, FrameLayout.LayoutParams(dp(44), dp(44))) }
    }

    fun start() {
        if (started) return
        if (ContextCompat.checkSelfPermission(act, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return
        started = true
        val f = ProcessCameraProvider.getInstance(act)
        f.addListener({
            try {
                val p = f.get()
                val pr = Preview.Builder().build()
                pr.setSurfaceProvider(preview.surfaceProvider)
                val an = tracker.analysis()
                p.bindToLifecycle(act, CameraSelector.DEFAULT_FRONT_CAMERA, pr, an)
                provider = p; useCase = pr; analysisCase = an
                tracker.prepare()
            } catch (_: Exception) { started = false }
        }, ContextCompat.getMainExecutor(act))
    }

    fun stop() {
        useCase?.let { provider?.unbind(it) }
        analysisCase?.let { provider?.unbind(it) }
        useCase = null; analysisCase = null; started = false
        cursors.forEach { it.visibility = View.GONE }
        drop(0); drop(1)
    }

    fun destroy() { tracker.close() }

    private fun inside(v: View, sx: Float, sy: Float): Boolean {
        val l = IntArray(2); v.getLocationOnScreen(l)
        return sx >= l[0] && sx <= l[0] + v.width && sy >= l[1] && sy <= l[1] + v.height
    }

    private fun hit(root: View, sx: Float, sy: Float): View? {
        if (root.visibility != View.VISIBLE || !inside(root, sx, sy)) return null
        if (root is ViewGroup) {
            for (k in root.childCount - 1 downTo 0) {
                val r = hit(root.getChildAt(k), sx, sy)
                if (r != null) return r
            }
        }
        return if (root.isClickable && root !is Dot) root else null
    }

    private fun drop(i: Int) { grabbed[i]?.grab(false); grabbed[i] = null; pinching[i] = false }

    private fun press(i: Int, sx: Float, sy: Float) {
        for (k in childCount - 1 downTo 0) {
            val v = getChildAt(k)
            if (v is GlassPanel && inside(v.titleView, sx, sy)) {
                grabbed[i] = v; v.grab(true); onSelect(v); v.bringToFront()
                cursors.forEach { it.bringToFront() }
                return
            }
        }
        hit(this, sx, sy)?.performClick()
    }

    /** اليد الأولى والثانية: مؤشر أخضر يتبع السبابة، والقرص (إبهام+سبابة) يمسك اللوح من عنوانه أو يضغط الزر. */
    private fun onHands(hands: List<Hand>, iw: Int, ih: Int) {
        val vw = width.toFloat(); val vh = height.toFloat()
        if (vw <= 0f || vh <= 0f || iw <= 0 || ih <= 0) return
        val s = maxOf(vw / iw, vh / ih)
        val ox = (vw - iw * s) / 2f; val oy = (vh - ih * s) / 2f
        val loc = IntArray(2); getLocationOnScreen(loc)
        for (i in 0..1) {
            val cur = cursors[i]
            if (i >= hands.size) { cur.visibility = View.GONE; drop(i); continue }
            val h = hands[i]
            val px = ox + h.x * iw * s; val py = oy + h.y * ih * s
            cur.visibility = View.VISIBLE
            cur.x = px - dp(22); cur.y = py - dp(22)
            val was = pinching[i]
            val now = if (was) h.pinchRatio < 0.40f else h.pinchRatio < 0.25f
            pinching[i] = now
            cur.filled = now; cur.invalidate()
            if (now && !was) press(i, loc[0] + px, loc[1] + py)
            if (!now && was) drop(i)
            val g = grabbed[i]
            if (now && g != null) { g.x += px - lastX[i]; g.y += py - lastY[i] }
            lastX[i] = px; lastY[i] = py
        }
    }

    private class Dot(c: Context) : View(c) {
        var filled = false
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(cv: Canvas) {
            val r = width / 2f
            p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.color = 0xFF22E08A.toInt()
            cv.drawCircle(r, r, r - 4f, p)
            p.style = Paint.Style.FILL; p.color = if (filled) 0xFF22E08A.toInt() else 0x8822E08A.toInt()
            cv.drawCircle(r, r, if (filled) r * 0.6f else r * 0.25f, p)
        }
    }

    private fun toggle(key: String) {
        val old = panels[key]
        if (old != null) { removeView(old); panels.remove(key); return }
        val (title, width) = when (key) {
            "apps" -> "التطبيقات" to 220
            "photos" -> "الصور" to 270
            "files" -> "الملفات" to 240
            else -> "المتصفح" to 310
        }
        val p = GlassPanel(act, title, onSelect)
        when (key) {
            "apps" -> appsContent(p)
            "photos" -> photosContent(p)
            "files" -> filesContent(p)
            else -> browserContent(p)
        }
        addView(p, FrameLayout.LayoutParams(dp(width), -2).apply {
            gravity = Gravity.TOP or Gravity.START
            leftMargin = dp(16 + cascade * 14); topMargin = dp(80 + cascade * 14)
        })
        cascade = (cascade + 1) % 5
        onSelect(p); panels[key] = p
        cursors.forEach { it.bringToFront() }
    }

    private fun appsContent(p: GlassPanel) {
        val list = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        val pm = act.packageManager
        pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .sortedBy { it.loadLabel(pm).toString() }.take(80).forEach { ri ->
                list.addView(TextView(act).apply {
                    text = "▸ " + ri.loadLabel(pm)
                    setTextColor(0xFFCFEFFF.toInt()); textSize = 13f
                    setPadding(dp(4), dp(7), dp(4), dp(7))
                    setOnClickListener { pm.getLaunchIntentForPackage(ri.activityInfo.packageName)?.let { act.startActivity(it) } }
                })
            }
        p.addView(ScrollView(act).apply { addView(list) }, LinearLayout.LayoutParams(-1, dp(240)))
    }

    private fun thumb(uri: Uri): Bitmap? = try {
        act.contentResolver.openInputStream(uri)?.use { s ->
            BitmapFactory.decodeStream(s, null, BitmapFactory.Options().apply { inSampleSize = 8 })
        }
    } catch (e: Exception) { null }

    private fun photosContent(p: GlassPanel) {
        val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(act, perm) != PackageManager.PERMISSION_GRANTED) {
            p.addRow("اضغط هنا للسماح بالوصول للصور، ثم أعد فتح النافذة")
                .setOnClickListener { act.requestPermissions(arrayOf(perm), 3) }
            return
        }
        val uriBase = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val ids = ArrayList<Long>()
        act.contentResolver.query(uriBase, arrayOf(MediaStore.Images.Media._ID), null, null,
            MediaStore.Images.Media.DATE_ADDED + " DESC")?.use { c ->
            var k = 0
            while (c.moveToNext() && k < 12) { ids.add(c.getLong(0)); k++ }
        }
        val grid = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        var row: LinearLayout? = null
        ids.forEachIndexed { i, id ->
            if (i % 3 == 0) { val r = LinearLayout(act); row = r; grid.addView(r) }
            val uri = ContentUris.withAppendedId(uriBase, id)
            val iv = ImageView(act).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setImageBitmap(thumb(uri))
                setOnClickListener {
                    act.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "image/*")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                }
            }
            row!!.addView(iv, LinearLayout.LayoutParams(dp(80), dp(80)).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
        }
        if (ids.isEmpty()) p.addRow("لا توجد صور")
        p.addView(ScrollView(act).apply { addView(grid) }, LinearLayout.LayoutParams(-1, dp(250)))
    }

    private fun filesContent(p: GlassPanel) {
        p.addRow("▸ التنزيلات").setOnClickListener {
            try { act.startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)) } catch (_: Exception) {}
        }
        p.addRow("▸ تصفح الملفات").setOnClickListener {
            try { act.startActivity(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")) } catch (_: Exception) {}
        }
    }

    private fun browserContent(p: GlassPanel) {
        val url = EditText(act).apply {
            hint = "ابحث أو اكتب رابطاً"; setTextColor(-1); setHintTextColor(0xFF668899.toInt()); textSize = 13f
            setBackgroundColor(0x22FFFFFF); setSingleLine(true); imeOptions = EditorInfo.IME_ACTION_GO
        }
        val wv = WebView(act).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
        }
        url.setOnEditorActionListener { v, _, _ ->
            val t = v.text.toString().trim()
            val u = if (t.startsWith("http")) t else if (t.contains(".") && !t.contains(" ")) "https://$t"
                    else "https://www.google.com/search?q=" + Uri.encode(t)
            wv.loadUrl(u); true
        }
        p.addView(url)
        p.addView(wv, LinearLayout.LayoutParams(-1, dp(260)))
        wv.loadUrl("https://www.google.com")
    }
}
