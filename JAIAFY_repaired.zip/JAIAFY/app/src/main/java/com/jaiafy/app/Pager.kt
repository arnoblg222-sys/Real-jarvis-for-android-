package com.jaiafy.app
import android.content.Context
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import kotlin.math.abs

/** ثلاث صفحات: الكرة، الوجه، المكتب. السحب الأفقي يبدّل بين أول صفحتين، والنقاط في الأعلى تبدّل بين الكل. */
class Pager(ctx: Context, private val pages: List<View>, private val onChange: (Int) -> Unit) : FrameLayout(ctx) {
    var index = 0
        private set

    private val gd = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
            if (index == pages.size - 1) return false
            if (abs(vx) > 900 && abs(vx) > abs(vy)) { go(if (vx < 0) index + 1 else index - 1); return true }
            return false
        }
    })

    init {
        pages.forEachIndexed { i, v ->
            addView(v, FrameLayout.LayoutParams(-1, -1))
            v.visibility = if (i == 0) View.VISIBLE else View.GONE
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean { gd.onTouchEvent(ev); return super.dispatchTouchEvent(ev) }

    fun go(i: Int) {
        if (i < 0 || i >= pages.size || i == index) return
        pages[index].visibility = View.GONE
        index = i
        pages[i].visibility = View.VISIBLE
        pages[i].alpha = 0f
        pages[i].animate().alpha(1f).setDuration(250).start()
        onChange(i)
    }
}
