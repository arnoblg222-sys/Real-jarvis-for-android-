package com.jaiafy.app
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.camera.core.ImageAnalysis
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.util.concurrent.Executors
import kotlin.math.hypot

/** يد واحدة: موضع رأس السبابة (0..1 بعد القلب كالمرآة)، ونسبة القرص (إبهام-سبابة)، وهل الكف مفتوح. */
class Hand(val x: Float, val y: Float, val pinchRatio: Float, val open: Boolean)

/** تتبع اليدين بـ MediaPipe. النموذج (نحو 8 ميجابايت) يُحمَّل مرة واحدة عند أول تشغيل. */
class HandTracker(
    private val ctx: Context,
    private val onFrame: (List<Hand>, Int, Int) -> Unit,
    private val onStatus: (String) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()
    @Volatile private var landmarker: HandLandmarker? = null
    @Volatile private var preparing = false
    private val modelUrl = "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"

    fun prepare() {
        if (landmarker != null || preparing) return
        preparing = true
        Thread {
            try {
                val f = File(ctx.filesDir, "hand_landmarker.task")
                if (!f.exists() || f.length() < 1_000_000L) {
                    main.post { onStatus("جارٍ تحميل نموذج اليد...") }
                    val tmp = File(ctx.filesDir, "hand.tmp")
                    val con = URL(modelUrl).openConnection() as HttpURLConnection
                    con.connectTimeout = 15000; con.readTimeout = 60000
                    con.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                    tmp.renameTo(f)
                }
                val bytes = f.readBytes()
                val bb = ByteBuffer.allocateDirect(bytes.size)
                bb.put(bytes); bb.rewind()
                val opts = HandLandmarker.HandLandmarkerOptions.builder()
                    .setBaseOptions(BaseOptions.builder().setModelAssetBuffer(bb).build())
                    .setRunningMode(RunningMode.VIDEO)
                    .setNumHands(2)
                    .build()
                landmarker = HandLandmarker.createFromOptions(ctx, opts)
                main.post { onStatus("تتبع اليدين نشط: اقرص بالإبهام والسبابة للإمساك") }
            } catch (e: Exception) {
                main.post { onStatus("تعذر تشغيل تتبع اليد: " + (e.message ?: "")) }
            }
            preparing = false
        }.start()
    }

    fun analysis(): ImageAnalysis {
        val a = ImageAnalysis.Builder()
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
            .build()
        a.setAnalyzer(exec) { proxy ->
            try {
                val lm = landmarker
                if (lm != null) {
                    val raw = Bitmap.createBitmap(proxy.width, proxy.height, Bitmap.Config.ARGB_8888)
                    raw.copyPixelsFromBuffer(proxy.planes[0].buffer)
                    val m = Matrix()
                    m.postRotate(proxy.imageInfo.rotationDegrees.toFloat())
                    m.postScale(-1f, 1f)
                    val bmp = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
                    val res = lm.detectForVideo(BitmapImageBuilder(bmp).build(), SystemClock.uptimeMillis())
                    val hands = res.landmarks().map { p ->
                        val size = hypot(p[0].x() - p[9].x(), p[0].y() - p[9].y()).coerceAtLeast(0.01f)
                        val ratio = hypot(p[4].x() - p[8].x(), p[4].y() - p[8].y()) / size
                        val ext = listOf(8 to 6, 12 to 10, 16 to 14, 20 to 18).count { p[it.first].y() < p[it.second].y() }
                        Hand(p[8].x(), p[8].y(), ratio, ext >= 4)
                    }
                    val w = bmp.width; val h = bmp.height
                    main.post { onFrame(hands, w, h) }
                }
            } catch (_: Exception) {
            } finally {
                proxy.close()
            }
        }
        return a
    }

    fun close() {
        try { landmarker?.close() } catch (_: Exception) {}
        landmarker = null
        exec.shutdown()
    }
}
