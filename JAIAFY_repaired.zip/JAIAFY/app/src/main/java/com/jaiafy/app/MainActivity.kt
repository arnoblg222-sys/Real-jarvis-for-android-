package com.jaiafy.app
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Button
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

/** ثلاث صفحات: الكرة الزرقاء، الوجه، Holo Desk. أيقونة الإعدادات أعلى اليمين. تُفتح بقفل الوجه. */
class MainActivity : FragmentActivity() {
    private val need = arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA,
        Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.CALL_PHONE)
    private var pager: Pager? = null
    private var deskRef: HoloDeskView? = null
    private var pendingPage = -1
    private var speech: SpeechRecognizer? = null
    private lateinit var speaker: Speaker
    private lateinit var memory: Memory
    private lateinit var actions: Actions
    private var micButton: TextView? = null

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        pendingPage = intent.getIntExtra("page", -1)
        val weak = BiometricManager.Authenticators.BIOMETRIC_WEAK
        if (BiometricManager.from(this).canAuthenticate(weak) != BiometricManager.BIOMETRIC_SUCCESS) {
            Toast.makeText(this, "سجّل بصمة وجهك في إعدادات الجوال أولاً", Toast.LENGTH_LONG).show()
            finish(); return
        }
        BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult) = buildUi()
            override fun onAuthenticationError(c: Int, m: CharSequence) = finish()
        }).authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("جايفاي")
            .setSubtitle("ضع وجهك أمام الكاميرا")
            .setNegativeButtonText("إلغاء")
            .setAllowedAuthenticators(weak).build())
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val p = intent.getIntExtra("page", -1)
        if (p >= 0) { val pg = pager; if (pg != null) pg.go(p) else pendingPage = p }
    }

    override fun onDestroy() { speech?.destroy(); if (::speaker.isInitialized) speaker.shutdown(); deskRef?.destroy(); super.onDestroy() }
    override fun onStart() { super.onStart(); OverlayCore.hide(this) }
    override fun onStop() { OverlayCore.show(this); super.onStop() }

    private fun buildUi() {
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        speaker = Speaker(this); memory = Memory(this); actions = Actions(this, memory)
        val hud = JarvisHud(this)
        val face = FaceView(this)
        val desk = HoloDeskView(this)
        deskRef = desk
        val dots = List(3) {
            TextView(this).apply { text = "●"; textSize = 14f; setPadding(dp(8), dp(6), dp(8), dp(6)) }
        }
        fun paintDots(i: Int) {
            dots.forEachIndexed { k, v -> v.setTextColor(if (k == i) 0xFFFFFFFF.toInt() else 0x66FFFFFF) }
        }
        val pg = Pager(this, listOf(hud, face, desk)) { i ->
            paintDots(i)
            if (i == 2) desk.start() else desk.stop()
        }
        pager = pg
        dots.forEachIndexed { k, v -> v.setOnClickListener { pg.go(k) } }
        paintDots(0)
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            dots.forEach { addView(it) }
        }
        val gear = TextView(this).apply {
            text = "⚙"; textSize = 26f; setTextColor(0xCC5FE3FF.toInt())
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }
        val root = FrameLayout(this)
        root.addView(pg, FrameLayout.LayoutParams(-1, -1))
        root.addView(bar, FrameLayout.LayoutParams(-2, -2).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; topMargin = dp(28) })
        val mic = TextView(this).apply {
            text = "🎙 تحدث إلى جايفاي"; textSize = 16f; gravity = Gravity.CENTER
            setTextColor(0xFF5FE3FF.toInt()); setPadding(dp(18), dp(12), dp(18), dp(12))
            setBackgroundColor(0xCC071827.toInt()); setOnClickListener { beginVoice() }
        }
        micButton = mic
        root.addView(mic, FrameLayout.LayoutParams(-2, -2).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; bottomMargin = dp(20) })
        root.addView(gear, FrameLayout.LayoutParams(-2, -2).apply {
            gravity = Gravity.TOP or Gravity.END; topMargin = dp(20); rightMargin = dp(4) })
        setContentView(root)

        if (pendingPage >= 0) { pg.go(pendingPage); pendingPage = -1 }
        if (Brain.get(this, "key").isBlank()) startActivity(Intent(this, SettingsActivity::class.java))
        val missing = need.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 1)
    }

    private fun beginVoice() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 42); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { Toast.makeText(this, "خدمة التعرف على الكلام غير متاحة", Toast.LENGTH_LONG).show(); return }
        speech?.destroy()
        micButton?.text = "🎙 أستمع الآن…"
        speech = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    micButton?.text = "🎙 تحدث إلى جايفاي"
                    destroy(); speech = null
                    if (heard.isBlank()) { Toast.makeText(this@MainActivity, "لم أسمع كلامًا", Toast.LENGTH_SHORT).show(); return }
                    micButton?.text = "⏳ يفكر…"
                    Thread {
                        val result = Brain.ask(this@MainActivity, heard, memory.all())
                        val arr = result.optJSONArray("actions")
                        if (arr != null) for (i in 0 until arr.length()) try { actions.run(arr.getJSONObject(i)) } catch (_: Exception) {}
                        val answer = result.optString("say").ifBlank { "تم" }
                        runOnUiThread { micButton?.text = "🎙 تحدث إلى جايفاي"; speaker.say(answer) }
                    }.start()
                }
                override fun onError(error: Int) { micButton?.text = "🎙 تحدث إلى جايفاي"; destroy(); speech = null; Toast.makeText(this@MainActivity, "تعذر التعرف على الصوت", Toast.LENGTH_SHORT).show() }
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM).putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA"))
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }
}
