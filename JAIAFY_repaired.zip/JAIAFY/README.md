# JAIAFY (repaired)

- Removed background clap detection / microphone monitoring service.
- Voice input now starts only when the user taps the "تحدث إلى جايفاي" button.
- Speech is recognized in Arabic, sent to the configured brain API, and the response is spoken using Speaker.
- Holo Desk hand tracking remains within the Holo Desk screen while that screen is active.

Build using Android Studio (open this folder as a Gradle project). Build verification was not possible in this environment because Gradle is not installed.
